<?php
// Assuming you have a MySQL database setup with appropriate credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "orderDB";

// Create a new connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare the SQL statements
$insertStmt = $conn->prepare("INSERT INTO orders (name, email, phone, address, city, zipcode, items, special_requests, card_number, expiration_date, cvv) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$deleteStmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Check if the delete form is submitted
    if (isset($_POST["delete-order"])) {
        // Retrieve the order ID from the form
        $orderId = $_POST["order-id"];

        // Bind the order ID parameter with the form data
        $deleteStmt->bind_param("i", $orderId);

        // Execute the delete statement
        if ($deleteStmt->execute()) {
            echo "Order deleted successfully.";
        } else {
            echo "Error deleting order: " . $deleteStmt->error;
        }
    } else {
        // Retrieve form data
        $name = $_POST["name"];
        $email = $_POST["email"];
        $phone = $_POST["phone"];
        $address = $_POST["address"];
        $city = $_POST["city"];
        $zipcode = $_POST["zipcode"];
        $items = $_POST["items"];
        $specialRequests = $_POST["special-requests"];
        $cardNumber = $_POST["card-number"];
        $expirationDate = $_POST["expiration-date"];
        $cvv = $_POST["cvv"];

        // Bind the parameters with the form data
        $insertStmt->bind_param("sssssssssss", $name, $email, $phone, $address, $city, $zipcode, $items, $specialRequests, $cardNumber, $expirationDate, $cvv);

        // Execute the insert statement
        if ($insertStmt->execute()) {
            // Set a cookie with the customer's name
            setcookie("customer_name", $name, time() + (86400 * 30), "/"); // Expires in 30 days

            // Redirect the user to a thank you page or display a success message
            header("Location: thank-you.php");
            exit;
        } else {
            // Display an error message
            echo "Error inserting order: " . $insertStmt->error;
        }
    }
}

// Close the prepared statements and database connection
$insertStmt->close();
$deleteStmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Order Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h1 {
            color: #333;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"] {
            padding: 5px;
            border: 1px solid #ccc;
        }

        button {
            padding: 5px 10px;
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <h1>Order Form</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" required>

        <label for="email">Email:</label>
        <input type="text" name="email" id="email" required>

        <label for="phone">Phone:</label>
        <input type="text" name="phone" id="phone" required>

        <label for="address">Address:</label>
        <input type="text" name="address" id="address" required>

        <label for="city">City:</label>
        <input type="text" name="city" id="city" required>

        <label for="zipcode">Zipcode:</label>
        <input type="text" name="zipcode" id="zipcode" required>

        <label for="items">Items:</label>
        <input type="text" name="items" id="items" required>

        <label for="special-requests">Special Requests:</label>
        <input type="text" name="special-requests" id="special-requests">

        <label for="card-number">Card Number:</label>
        <input type="text" name="card-number" id="card-number" required>

        <label for="expiration-date">Expiration Date:</label>
        <input type="text" name="expiration-date" id="expiration-date" required>

        <label for="cvv">CVV:</label>
        <input type="text" name="cvv" id="cvv" required>

        <button type="submit">Place Order</button>
    </form>

    <h2>Delete Order</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="order-id">Order ID:</label>
        <input type="text" name="order-id" id="order-id" required>

        <button type="submit" name="delete-order">Delete Order</button>
    </form>
</body>
</html>
