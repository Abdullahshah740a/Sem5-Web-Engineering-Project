<!DOCTYPE html>
<html>
<head>
    <title>Booking Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
        }

        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            border: 1px solid #dddddd;
            border-radius: 5px;
            margin-top: 50px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
        }

        .success {
            color: #4CAF50;
        }

        .error {
            color: #F44336;
        }

        .btn {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: #ffffff;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Booking Result</h1>
        <?php
        // Establish database connection
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "database_project";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Get form inputs
        $people = $_POST['people'];
        $time = $_POST['time'];
        $phone = $_POST['phone'];
        $date = $_POST['date'];
        $name = $_POST['name'];
        $email = $_POST['email'];

        // Prepare and execute the SQL query
        $stmt = $conn->prepare("INSERT INTO bookings (people, time, phone, date, name, email) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $people, $time, $phone, $date, $name, $email);

        $result = $stmt->execute();

        // Close statement and database connection
        $stmt->close();
        $conn->close();

        if ($result) {
            echo '<p class="success">Booking submitted successfully!</p>';
        } else {
            echo '<p class="error">Error: ' . $stmt->error . '</p>';
        }
        ?>
        <a class="btn" href="index.php">Back to Home</a>
    </div>
</body>
</html>
