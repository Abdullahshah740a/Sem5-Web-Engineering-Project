<?php
// Assuming you have a MySQL database setup with appropriate credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "orderDB";

// Create a new connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the last inserted order
$sql = "SELECT * FROM orders ORDER BY order_id DESC LIMIT 1"; // 1 complete row
$result = $conn->query($sql); //stored in result

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc(); //returns row data inform of array
?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Thank You</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f2f2f2;
                padding: 20px;
            }

            h1, h2 {
                text-align: center;
                color: #333;
            }

            p {
                font-size: 16px;
                margin-bottom: 10px;
            }

            .container {
                max-width: 600px;
                margin: 0 auto;
                background-color: #fff;
                padding: 30px;
                border-radius: 5px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }

            .button {
                display: inline-block;
                padding: 10px 20px;
                background-color: #333;
                color: #fff;
                text-decoration: none;
                border-radius: 5px;
                transition: background-color 0.3s ease;
            }

            .button:hover {
                background-color: #555;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Thank You for Your Order!</h1>
            <h2>Order Details:</h2>
            <p><strong>Name:</strong> <?php echo $row['name']; ?></p>
            <p><strong>Email:</strong> <?php echo $row['email']; ?></p>
            <p><strong>Phone:</strong> <?php echo $row['phone']; ?></p>
            <p><strong>Address:</strong> <?php echo $row['address']; ?></p>
            <p><strong>City:</strong> <?php echo $row['city']; ?></p>
            <p><strong>ZIP Code:</strong> <?php echo $row['zipcode']; ?></p>
            <p><strong>Items:</strong> <?php echo $row['items']; ?></p>
            <p><strong>Special Requests:</strong> <?php echo $row['special_requests']; ?></p>1
            <p><strong>Card Number:</strong> <?php echo $row['card_number']; ?></p>
            <p><strong>Expiration Date:</strong> <?php echo $row['expiration_date']; ?></p>
            <p><strong>CVV:</strong> <?php echo $row['cvv']; ?></p>

           <center>
           <a class="button" href="index.php">Back to Home</a>
           </center>
        </div>
    </body>
    </html>
<?php
} else {
    echo "No order found.";
}

// Close the database connection
$conn->close();
?>
