<!DOCTYPE html>
<html>

<head>
    <title>Order Management</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        .delete-btn {
            background-color: #f44336;
            color: #fff;
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <h1>Order Management</h1>
    <?php
    // Assuming you have a MySQL database setup with appropriate credentials
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "orderDB";

    // Create a new connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the delete button is clicked
    if (isset($_POST['delete'])) {
        if (isset($_POST['order_id']) && !empty($_POST['order_id'])) { //Ensures the order_id is provided and not empty
            $orderId = $_POST['order_id']; // Get the order ID from the form

            // Prepare the SQL statement to delete the order
            $stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
            $stmt->bind_param("i", $orderId); // Bind the orderId to the prepared statement

            // Execute the prepared statement
            if ($stmt->execute()) {
                echo "Record deleted successfully.";
            } else {
                echo "Error deleting record: " . $stmt->error;
            }

            // Close the prepared statement
            $stmt->close();
        } else {
            echo "Order ID not set or is empty!";
        }
    }

    // Retrieve data from the orders table
    $sql = "SELECT * FROM orders";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>Order ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Address</th><th>City</th><th>ZIP Code</th><th>Items</th><th>Special Requests</th><th>Action</th></tr>";
        
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["order_id"] . "</td>";  // Use order_id here
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["email"] . "</td>";
            echo "<td>" . $row["phone"] . "</td>";
            echo "<td>" . $row["address"] . "</td>";
            echo "<td>" . $row["city"] . "</td>";
            echo "<td>" . $row["zipcode"] . "</td>";
            echo "<td>" . $row["items"] . "</td>";
            echo "<td>" . $row["special_requests"] . "</td>";
            
            // The delete button for each row
            echo "<td>
                    <form method='post'>
                        <input type='hidden' name='order_id' value='" . $row["order_id"] . "'> <!-- Pass the order ID -->
                        <button type='submit' class='delete-btn' name='delete'>Delete</button>
                    </form>
                </td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No orders found.";
    }

    // Close the database connection
    $conn->close();
    ?>
</body>

</html>
