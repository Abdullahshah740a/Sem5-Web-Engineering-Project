<!DOCTYPE html>
<html>
  <head>
    <title>Restaurant Order Form</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #333;
        padding: 20px;
      }

      h1 {
        text-align: center;
        color: #333;
      }

      form {
        max-width: 500px;
        margin: 0 auto;
        background-color: #fff;
        padding: 30px;
        border-radius: 5px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      }

      label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
      }

      input[type="text"],
      input[type="email"],
      input[type="tel"],
      textarea {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 3px;
        margin-bottom: 15px;
      }

      textarea {
        resize: vertical;
      }

      button[type="submit"] {
        background-color: #4caf50;
        color: #fff;
        padding: 10px 20px;
        border: none;
        border-radius: 3px;
        cursor: pointer;
        font-size: 16px;
      }

      button[type="submit"]:hover {
        background-color: #45a049;
      }
    </style>
  </head>

  <body>
    <h1>Restaurant Order Form</h1>
    <form
      action="submit-order.php"
      method="post"
      onsubmit="return validateForm()"
    >
      <h2>Contact Information</h2>
      <label for="name">Name:</label>
      <input type="text" id="name" name="name" required />

      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required />

      <label for="phone">Phone:</label>
      <input type="tel" id="phone" name="phone" required />

      <h2>Delivery Address</h2>
      <label for="address">Address:</label>
      <textarea id="address" name="address" rows="4" required></textarea>

      <label for="city">City:</label>
      <input type="text" id="city" name="city" required />

      <label for="zipcode">ZIP Code:</label>
      <input type="text" id="zipcode" name="zipcode" required />

      <h2>Order Details</h2>
      <label for="items">Items:</label><br />
      <textarea id="items" name="items" rows="4" required></textarea>

      <label for="special-requests">Special Requests:</label><br />
      <textarea
        id="special-requests"
        name="special-requests"
        rows="4"
      ></textarea>

      <h2>Payment Information</h2>
      <label for="card-number">Card Number:</label>
      <input type="text" id="card-number" name="card-number" required />

      <label for="expiration-date">Expiration Date:</label>
      <input type="text" id="expiration-date" name="expiration-date" required />

      <label for="cvv">CVV:</label>
      <input type="text" id="cvv" name="cvv" required />

      <button type="submit">Place Order</button>
      <h2>Delete Order</h2>
   
      <button><a href="delete.php">Delete Order</a></button>
    </form>
    <script>
      function validateForm() {
        // Validate form fields here
        var name = document.getElementById("name").value;
        var email = document.getElementById("email").value;
        var phone = document.getElementById("phone").value;
        var address = document.getElementById("address").value;
        var city = document.getElementById("city").value;
        var zipcode = document.getElementById("zipcode").value;
        var items = document.getElementById("items").value;
        var cardNumber = document.getElementById("card-number").value;
        var expirationDate = document.getElementById("expiration-date").value;
        var cvv = document.getElementById("cvv").value;

        // Perform validation checks
        if (
          name === "" ||
          email === "" ||
          phone === "" ||
          address === "" ||
          city === "" ||
          zipcode === "" ||
          items === "" ||
          cardNumber === "" ||
          expirationDate === "" ||
          cvv === ""
        ) {
          alert("Please fill in all required fields.");
          return false;
        }

        // Additional validation checks can be added here

        return true;
      }
    </script>
  </body>
</html>
