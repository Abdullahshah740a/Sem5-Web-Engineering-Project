<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Royate</title>
    <!-- Font Awesome library ka CSS stylesheet to use icons-->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <!-- Swiper library ka CSS stylesheet  -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"
    />
    <link rel="icon" href="logo.png" /> <!--icon for tab-->
    <link rel="stylesheet" href="style.css" />
  </head>

  <body>
    <header>
      <a href="#" class="logo"><img src="logo.png" alt="logo-img" /></a>
      <nav class="navbar">
        <a href="#home" class="active">home</a>
        <a href="#about">about</a>
        <a href="#menu2">menu</a>
        <a href="#team">team</a>
        <a href="#reservation">reservation</a>
        <a href="#blog">blog</a>
      </nav>
      <div class="icons">
        <i class="fas fa-bars" id="menu"></i>
        <i class="fas fa-search"></i>
        <i class="fas fa-heart"></i>
        <i class="fas fa-shopping-cart"></i>
      </div>
    </header>

    <div class="home" id="home">
      <div class="swiper mySwiper home-slider">
        <div class="swiper-wrapper wrapper">
          <div class="swiper-slide slide slide1">
            <div class="content">
              <img src="crown-symbol.png" alt="crown-symbol-img" />

              <h3>delicious royate</h3>
              <h1>gift voucher</h1>
              <p>give away your beloved customers</p>
              <a href="order.php" class="btn">order now</a>
            </div>
          </div>

          <div class="swiper-slide slide slide2">
            <div class="content">
              <img src="crown-symbol.png" alt="crown-symbol-img" />

              <h3>sale of 10% this dish</h3>
              <h1>the fresh</h1>
              <p>food restaurant</p>
              <a href="order.html" class="btn">order now</a>
            </div>
          </div>

          <div class="swiper-slide slide slide3">
            <div class="content">
              <img src="crown-symbol.png" alt="crown-symbol-img" />

              <h3>we are open</h3>
              <h1>fresh fruits</h1>
              <p>you will love it</p>
              <a href="order.html" class="btn">order now</a>
            </div>
          </div>
        </div>

        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>

        <div class="swiper-pagination"></div>
        <div style="display: none" class="autoplay-progress">
          <svg viewBox="0 0 48 48">
            <circle cx="24" cy="24" r="20"></circle>
          </svg>
          <span></span>
        </div>
      </div>
    </div>

    <!-- slider ends here -->

    <section class="welcome" id="about">
      <h1 class="heading">WELCOME TO ROYATE</h1>
      <center>
        <h3 class="sub-heading">~ Luxury & Quality ~</h3>
      </center>

      <div class="box-container">
        <div class="box">
          <div class="image">
            <img src="post-thumb-1.jpg" alt="post-thumb-Image" />
          </div>
          <div class="content">
            <h3>PROFESSIONAL LEVEL</h3>
            <p>
              nor again is there anyone who loves or pursues or desires to
              obtain pain of itself, becuase it is pain, but because
              occasionally circumstances occur.
            </p>
            <a href="#" class="btn">Read More</a>
          </div>
        </div>

        <div class="box">
          <div class="image">
            <img src="post-thumb-2.jpg" alt="post-thumb-Image" />
          </div>
          <div class="content">
            <h3>FRESH FOOD GUARANTEED</h3>
            <p>
              nor again is there anyone who loves or pursues or desires to
              obtain pain of itself, becuase it is pain, but because
              occasionally circumstances occur.
            </p>
            <a href="#" class="btn">Read More</a>
          </div>
        </div>

        <div class="box">
          <div class="image">
            <img src="post-thumb-3.jpg" alt="post-thumb-Image" />
          </div>
          <div class="content">
            <h3>THE MENU IS PLENTIFUL</h3>
            <p>
              nor again is there anyone who loves or pursues or desires to
              obtain pain of itself, becuase it is pain, but because
              occasionally circumstances occur.
            </p>
            <a href="#" class="btn">Read More</a>
          </div>
        </div>
      </div>
    </section>

    <!-- menu section start -->

    <section class="our-menu" id="menu2">
      <h1 class="heading">our food menu</h1>
      <center>
        <h3 class="sub-heading">~ see what we offer ~</h3>
      </center>

      <div class="menu-container">
        <div class="item">
          <div class="item-name">
            <h2>Main Course</h2>
            <img src="drinks.png" alt="drinks Image" />
          </div>
          <div class="item-body">
            <div class="item-menu">
              <h3>Super-Delicious Zuppa Toscana</h3>
              <span class="dots"></span>
              <h3>$40</h3>

              <ul>
                <li><a href="#">Chicken</a></li>
                <li><a href="#">Italian</a></li>
                <li><a href="#">Sausage</a></li>
                <li><a href="#">Spinach</a></li>
              </ul>
            </div>

            <div class="item-menu">
              <h3>Super-Delicious Zuppa Toscana</h3>
              <span class="dots"></span>
              <h3>$26</h3>

              <ul>
                <li><a href="#">Mushrooms</a></li>
                <li><a href="#">Italian</a></li>
                <li><a href="#">Sausage</a></li>
                <li><a href="#">Spinach</a></li>
              </ul>
            </div>
          </div>
        </div>

        <div class="item">
          <div class="item-name">
            <h2>Soups & salads</h2>
            <img src="drinks.png" alt="drinks Image" />
          </div>
          <div class="item-body">
            <div class="item-menu">
              <h3>Super-Delicious Zuppa Toscana</h3>
              <span class="dots"></span>
              <h3>$40</h3>

              <ul>
                <li><a href="#">Chicken</a></li>
                <li><a href="#">Italian</a></li>
                <li><a href="#">Sausage</a></li>
                <li><a href="#">Spinach</a></li>
              </ul>
            </div>

            <div class="item-menu">
              <h3>Super-Delicious Zuppa Toscana</h3>
              <span class="dots"></span>
              <h3>$26</h3>

              <ul>
                <li><a href="#">Mushrooms</a></li>
                <li><a href="#">Italian</a></li>
                <li><a href="#">Sausage</a></li>
                <li><a href="#">Spinach</a></li>
              </ul>
            </div>
          </div>
        </div>

        <div class="item">
          <div class="item-name">
            <h2>Drinks</h2>
            <img src="drinks.png" alt="drinks Image" />
          </div>
          <div class="item-body">
            <div class="item-menu">
              <h3>Super-Delicious Zuppa Toscana</h3>
              <span class="dots"></span>
              <h3>$40</h3>

              <ul>
                <li><a href="#">Chicken</a></li>
                <li><a href="#">Italian</a></li>
                <li><a href="#">Sausage</a></li>
                <li><a href="#">Spinach</a></li>
              </ul>
            </div>

            <div class="item-menu">
              <h3>Super-Delicious Zuppa Toscana</h3>
              <span class="dots"></span>
              <h3>$26</h3>

              <ul>
                <li><a href="#">Mushrooms</a></li>
                <li><a href="#">Italian</a></li>
                <li><a href="#">Sausage</a></li>
                <li><a href="#">Spinach</a></li>
              </ul>
            </div>
          </div>
        </div>

        <div class="item">
          <div class="item-name">
            <h2>Desserts</h2>
            <img src="drinks.png" alt="drinks Image" />
          </div>
          <div class="item-body">
            <div class="item-menu">
              <h3>Super-Delicious Zuppa Toscana</h3>
              <span class="dots"></span>
              <h3>$40</h3>

              <ul>
                <li><a href="#">Chicken</a></li>
                <li><a href="#">Italian</a></li>
                <li><a href="#">Sausage</a></li>
                <li><a href="#">Spinach</a></li>
              </ul>
            </div>

            <div class="item-menu">
              <h3>Super-Delicious Zuppa Toscana</h3>
              <span class="dots"></span>
              <h3>$26</h3>

              <ul>
                <li><a href="#">Mushrooms</a></li>
                <li><a href="#">Italian</a></li>
                <li><a href="#">Sausage</a></li>
                <li><a href="#">Spinach</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- menu section end -->
    <!-- our team section start -->
    <section class="our-team" id="team">
      <h1 class="heading">our talented chef</h1>
      <center>
        <h3 class="sub-heading">~ Experience $ Enthusiam ~</h3>
      </center>

      <div class="our-chef">
        <div class="item">
          <div class="image">
            <img src="our-chef-1.jpg" alt="chef image" />
          </div>

          <div class="chef-info">
            <div>
              <h3>Jerry robertson</h3>
              <span>master chef</span>

              <ul>
                <li>
                  <a href="#">
                    <i class="fa-brands fa-instagram"></i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i class="fa-brands fa-twitter"></i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i class="fa-brands fa-whatsapp"></i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i class="fa-brands fa-linkedin-in"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div class="item">
          <div class="image">
            <img src="our-chef-2.jpg" alt="chef image" />
          </div>

          <div class="chef-info">
            <div>
              <h3>corol rowson</h3>
              <span>master chef</span>

              <ul>
                <li>
                  <a href="#">
                    <i class="fa-brands fa-instagram"></i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i class="fa-brands fa-twitter"></i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i class="fa-brands fa-whatsapp"></i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i class="fa-brands fa-linkedin-in"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div class="item">
          <div class="image">
            <img src="our-chef-3.jpg" alt="chef image" />
          </div>

          <div class="chef-info">
            <div>
              <h3>taylor mccoy</h3>
              <span>master chef</span>

              <ul>
                <li>
                  <a href="#">
                    <i class="fa-brands fa-instagram"></i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i class="fa-brands fa-twitter"></i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i class="fa-brands fa-whatsapp"></i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i class="fa-brands fa-linkedin-in"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- our team section end -->

    <!-- reservation section start here -->

    <div class="reservation" id="reservation">
      <div class="image"></div>

      <div class="form">
        <h1 class="heading">book a table</h1>
        <center>
          <h3 class="sub-heading">~ check out our place ~</h3>
        </center>

        <form action="submit.php" method="POST">
          <div class="form-holder">
            <div>
              <select name="people" id="people">
                <option value="1">1 People</option>
                <option value="2">2 People</option>
                <option value="3">3 People</option>
                <option value="4">4 People</option>
              </select>

              <input type="time" name="time" placeholder="Time" required />
              <input
                type="tel"
                name="phone"
                placeholder="Phone"
                required
                pattern="[0-9]{10}"
                title="Please enter a 10-digit phone number"
              />
            </div>
            <div>
              <input type="date" name="date" placeholder="Date" required />
              <input type="text" name="name" placeholder="Name" required />
              <input type="email" name="email" placeholder="Email" required />
            </div>
          </div>
          <center>
            <button type="submit" class="btn">Book Now</button>
          </center>
        </form>

        <!-- <div class="overlay" id="overlay">
          <div class="popup" id="popup">
            <h1 id="message"></h1>
            <button onclick="closePopup()">OK</button>
          </div>
        </div> -->

        <script>
          // function newtab(){
          //   window.open("details_entry.php", "_blank");
          // }
          // Function to validate the form
          function validateForm(event) {
            event.preventDefault(); // Prevent form submission if validation fails

            // Get form inputs
            var people = document.getElementById("people").value;
            var time = document.getElementsByName("time")[0].value;
            var phone = document.getElementsByName("phone")[0].value;
            var date = document.getElementsByName("date")[0].value;
            var name = document.getElementsByName("name")[0].value;
            var email = document.getElementsByName("email")[0].value;

            // Validate inputs
            if (people === "") {
              alert("Please select the number of people.");
              return;
            }

            if (time === "") {
              alert("Please enter the time.");
              return;
            }

            if (phone === "") {
              alert("Please enter your phone number.");
              return;
            }

            if (date === "") {
              alert("Please enter the date.");
              return;
            }

            if (name === "") {
              alert("Please enter your name.");
              return;
            }

            if (email === "") {
              alert("Please enter your email address.");
              return;
            }

            // If all inputs are valid, submit the form
            event.target.submit();
          }

          // Attach form submission listener
          document
            .getElementsByTagName("form")[0]
            .addEventListener("submit", validateForm);
        </script>

        <!-- <form action="">
          <div class="form-holder">
            <div>
              <select name="" id="">
                <option value="">1 People</option>
                <option value="">2 People</option>
                <option value="">3 People</option>
                <option value="">4 People</option>
              </select>

              <input type="text" name="" placeholder="Time" />
              <input type="text" name="" placeholder="Phone" />
            </div>
            <div>
              <input type="text" name="" placeholder="Date" />
              <input type="text" name="" placeholder="Name" />
              <input type="email" name="" placeholder="Email" />
            </div>
          </div>
          <center>
            <a href="#" class="btn">Book Now</a>
          </center>
        </form> -->
      </div>
    </div>

    <!-- reservation section end here -->

    <!-- news section start here  -->

    <section class="blog welcome" id="blog">
      <h1 class="heading">latest news</h1>
      <center>
        <h3 class="sub-heading">~ Great articles ~</h3>
      </center>

      <div class="box-container">
        <div class="box">
          <div class="image">
            <img src="post-thumb-4.jpg" alt="blog image" />
          </div>

          <div class="content">
            <h3>PROFESSIONAL LEVEL</h3>
            <p>
              nor again is there anyone who loves or pursues or desires to
              obtain pain of itself, becuase it is pain, but because
              occasionally circumstances occur.
            </p>
            <a href="#">READ MORE</a>
            <img src="post-body-bg-1.png" alt="post-body-bg" />
          </div>
        </div>

        <div class="box">
          <div class="image">
            <img src="post-thumb-5.jpg" alt="blog image" />
          </div>

          <div class="content">
            <h3>FRESH FOOG GUARANTEED</h3>
            <p>
              nor again is there anyone who loves or pursues or desires to
              obtain pain of itself, becuase it is pain, but because
              occasionally circumstances occur.
            </p>
            <a href="#">READ MORE</a>
            <img src="post-body-bg-2.png" alt="post-body-bg" />
          </div>
        </div>

        <div class="box">
          <div class="image">
            <img src="post-thumb-6.jpg" alt="blog image" />
          </div>

          <div class="content">
            <h3>THE MENU IS PLENTIFUL</h3>
            <p>
              nor again is there anyone who loves or pursues or desires to
              obtain pain of itself, becuase it is pain, but because
              occasionally circumstances occur.
            </p>
            <a href="#">READ MORE</a>
            <img src="post-body-bg-3.png" alt="post-body-bg" />
          </div>
        </div>
      </div>
    </section>

    <!-- news section end here  -->

    <!-- footer section start here  -->
    <section class="footer">
      <img src="logo.png" alt="logo" class="logo" />

      <div class="container">
        <div>
          <h3>ABOUT US</h3>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto
            deserunt accusantium.
          </p>
        </div>

        <div>
          <h3>GER NEWS & OFFERS</h3>
          <input type="text" name="" id="" placeholder="Enter your email" />
          <ul>
            <li>
              <a href="#"><i class="fa-brands fa-twitter"></i></a>
            </li>
            <li>
              <a href="#"><i class="fa-brands fa-instagram"></i></a>
            </li>
            <li>
              <a href="#"><i class="fa-brands fa-whatsapp"></i></a>
            </li>
            <li>
              <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
            </li>
          </ul>
        </div>

        <div>
          <h3>CONTACT US</h3>
          <span>John Dave</span>
          <span>+ (92) 3230123803</span>
          <span>johndave143@gmail.com</span>
          <span>johndave.com</span>
        </div>
      </div>

      <p>&copy;2023 Reserved by BSSE-5A</p>
    </section>
    <!-- footer section end here  -->

    <!-- jump to top -->
    <a href="#" class="topbtn"><i class="fa-solid fa-angle-up"></i></a>

    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>

    <!-- Initialize Swiper -->
    <script>
      const progressCircle = document.querySelector(".autoplay-progress svg");
      const progressContent = document.querySelector(".autoplay-progress span");
      var swiper = new Swiper(".mySwiper", {
        spaceBetween: 30,
        centeredSlides: true,
        autoplay: {
          delay: 3000,
          disableOnInteraction: false,
        },
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
        on: {
          autoplayTimeLeft(s, time, progress) {
            progressCircle.style.setProperty("--progress", 1 - progress);
            progressContent.textContent = `${Math.ceil(time / 1000)}s`;
          },
        },
      });
    </script>
  </body>
</html>
